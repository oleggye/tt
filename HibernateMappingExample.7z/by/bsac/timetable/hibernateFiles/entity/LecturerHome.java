package by.bsac.timetable.hibernateFiles.entity;
// Generated Aug 26, 2017 12:43:31 PM by Hibernate Tools 5.2.3.Final

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class Lecturer.
 * @see by.bsac.timetable.hibernateFiles.entity.Lecturer
 * @author Hibernate Tools
 */
public class LecturerHome {

	private static final Log log = LogFactory.getLog(LecturerHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext().lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException("Could not locate SessionFactory in JNDI");
		}
	}

	public void persist(Lecturer transientInstance) {
		log.debug("persisting Lecturer instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void attachDirty(Lecturer instance) {
		log.debug("attaching dirty Lecturer instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Lecturer instance) {
		log.debug("attaching clean Lecturer instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(Lecturer persistentInstance) {
		log.debug("deleting Lecturer instance");
		try {
			sessionFactory.getCurrentSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Lecturer merge(Lecturer detachedInstance) {
		log.debug("merging Lecturer instance");
		try {
			Lecturer result = (Lecturer) sessionFactory.getCurrentSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Lecturer findById(java.lang.Short id) {
		log.debug("getting Lecturer instance with id: " + id);
		try {
			Lecturer instance = (Lecturer) sessionFactory.getCurrentSession()
					.get("by.bsac.timetable.hibernateFiles.entity.Lecturer", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<Lecturer> findByExample(Lecturer instance) {
		log.debug("finding Lecturer instance by example");
		try {
			List<Lecturer> results = (List<Lecturer>) sessionFactory.getCurrentSession()
					.createCriteria("by.bsac.timetable.hibernateFiles.entity.Lecturer").add(create(instance)).list();
			log.debug("find by example successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
}
