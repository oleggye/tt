package by.bsac.timetable.hibernateFiles.entity;
// Generated Aug 26, 2017 12:43:31 PM by Hibernate Tools 5.2.3.Final

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class Faculty.
 * @see by.bsac.timetable.hibernateFiles.entity.Faculty
 * @author Hibernate Tools
 */
public class FacultyHome {

	private static final Log log = LogFactory.getLog(FacultyHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext().lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException("Could not locate SessionFactory in JNDI");
		}
	}

	public void persist(Faculty transientInstance) {
		log.debug("persisting Faculty instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void attachDirty(Faculty instance) {
		log.debug("attaching dirty Faculty instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Faculty instance) {
		log.debug("attaching clean Faculty instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(Faculty persistentInstance) {
		log.debug("deleting Faculty instance");
		try {
			sessionFactory.getCurrentSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Faculty merge(Faculty detachedInstance) {
		log.debug("merging Faculty instance");
		try {
			Faculty result = (Faculty) sessionFactory.getCurrentSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Faculty findById(short id) {
		log.debug("getting Faculty instance with id: " + id);
		try {
			Faculty instance = (Faculty) sessionFactory.getCurrentSession()
					.get("by.bsac.timetable.hibernateFiles.entity.Faculty", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<Faculty> findByExample(Faculty instance) {
		log.debug("finding Faculty instance by example");
		try {
			List<Faculty> results = (List<Faculty>) sessionFactory.getCurrentSession()
					.createCriteria("by.bsac.timetable.hibernateFiles.entity.Faculty").add(create(instance)).list();
			log.debug("find by example successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
}
