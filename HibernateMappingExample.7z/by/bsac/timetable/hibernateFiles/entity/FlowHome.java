package by.bsac.timetable.hibernateFiles.entity;
// Generated Aug 26, 2017 12:43:31 PM by Hibernate Tools 5.2.3.Final

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class Flow.
 * @see by.bsac.timetable.hibernateFiles.entity.Flow
 * @author Hibernate Tools
 */
public class FlowHome {

	private static final Log log = LogFactory.getLog(FlowHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext().lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException("Could not locate SessionFactory in JNDI");
		}
	}

	public void persist(Flow transientInstance) {
		log.debug("persisting Flow instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void attachDirty(Flow instance) {
		log.debug("attaching dirty Flow instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Flow instance) {
		log.debug("attaching clean Flow instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(Flow persistentInstance) {
		log.debug("deleting Flow instance");
		try {
			sessionFactory.getCurrentSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Flow merge(Flow detachedInstance) {
		log.debug("merging Flow instance");
		try {
			Flow result = (Flow) sessionFactory.getCurrentSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Flow findById(short id) {
		log.debug("getting Flow instance with id: " + id);
		try {
			Flow instance = (Flow) sessionFactory.getCurrentSession()
					.get("by.bsac.timetable.hibernateFiles.entity.Flow", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<Flow> findByExample(Flow instance) {
		log.debug("finding Flow instance by example");
		try {
			List<Flow> results = (List<Flow>) sessionFactory.getCurrentSession()
					.createCriteria("by.bsac.timetable.hibernateFiles.entity.Flow").add(create(instance)).list();
			log.debug("find by example successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
}
